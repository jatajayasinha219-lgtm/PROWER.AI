import { z } from "zod";

export const api = {
  conversations: {
    list: {
      method: "GET",
      path: "/api/conversations",
      responses: {
        200: z.array(z.object({
          id: z.number(),
          title: z.string(),
          createdAt: z.string().or(z.date())
        }))
      }
    },
    create: {
      method: "POST",
      path: "/api/conversations",
      input: z.object({
        title: z.string().optional()
      }),
      responses: {
        201: z.object({
          id: z.number(),
          title: z.string(),
          createdAt: z.string().or(z.date())
        })
      }
    },
    get: {
      method: "GET",
      path: "/api/conversations/:id",
      responses: {
        200: z.object({
          id: z.number(),
          title: z.string(),
          messages: z.array(z.object({
            id: z.number(),
            role: z.string(),
            content: z.string(),
            createdAt: z.string().or(z.date())
          }))
        })
      }
    },
    delete: {
      method: "DELETE",
      path: "/api/conversations/:id",
      responses: {
        204: z.void()
      }
    },
    sendMessage: {
      method: "POST",
      path: "/api/conversations/:id/messages",
      input: z.object({
        content: z.string(),
        attachments: z.array(z.string()).optional()
      }),
      // Response is SSE stream, not JSON
      responses: {}
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
