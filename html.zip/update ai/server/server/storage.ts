export { chatStorage as storage } from "./replit_integrations/chat/storage";
export type { IChatStorage as IStorage } from "./replit_integrations/chat/storage";
