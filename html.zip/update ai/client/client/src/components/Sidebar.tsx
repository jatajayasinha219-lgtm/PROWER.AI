import { Link, useLocation } from "wouter";
import { Plus, MessageSquare, Trash2, Menu, X } from "lucide-react";
import { useConversations, useCreateConversation, useDeleteConversation, type Conversation } from "@/hooks/use-chat";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useState } from "react";

export function Sidebar() {
  const [location, setLocation] = useLocation();
  const { data: conversations, isLoading } = useConversations();
  const createMutation = useCreateConversation();
  const deleteMutation = useDeleteConversation();
  const [isOpen, setIsOpen] = useState(false);

  // Extract ID from /chat/:id
  const currentId = location.split("/")[2] ? parseInt(location.split("/")[2]) : null;

  const handleCreate = async () => {
    const newConv = await createMutation.mutateAsync("New Chat");
    setLocation(`/chat/${newConv.id}`);
    setIsOpen(false);
  };

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this chat?")) {
      await deleteMutation.mutateAsync(id);
      if (currentId === id) {
        setLocation("/");
      }
    }
  };

  const ConversationList = () => (
    <div className="flex flex-col gap-2 p-2">
      <Button 
        onClick={handleCreate} 
        disabled={createMutation.isPending}
        className="w-full justify-start gap-2 bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 shadow-none mb-4"
      >
        <Plus className="w-4 h-4" />
        {createMutation.isPending ? "Creating..." : "New Chat"}
      </Button>

      <div className="text-xs font-semibold text-muted-foreground mb-2 px-2 uppercase tracking-wider">
        Recent Chats
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-10 bg-muted/50 rounded-lg animate-pulse" />
          ))}
        </div>
      ) : conversations?.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground text-sm">
          No conversations yet.
          <br />Start a new one!
        </div>
      ) : (
        conversations?.map((conv: Conversation) => (
          <div key={conv.id} className="group relative">
            <Link 
              href={`/chat/${conv.id}`}
              className={cn(
                "flex items-center gap-3 w-full p-3 rounded-lg text-sm transition-all duration-200",
                "hover:bg-secondary/80",
                currentId === conv.id 
                  ? "bg-secondary text-foreground font-medium shadow-sm border border-border/50" 
                  : "text-muted-foreground"
              )}
              onClick={() => setIsOpen(false)}
            >
              <MessageSquare className="w-4 h-4 shrink-0 opacity-70" />
              <div className="flex-1 truncate text-left">
                {conv.title || "New Conversation"}
              </div>
            </Link>
            <button
              onClick={(e) => handleDelete(e, conv.id)}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md opacity-0 group-hover:opacity-100 hover:bg-destructive/10 hover:text-destructive transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        ))
      )}
    </div>
  );

  return (
    <>
      {/* Mobile Trigger */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden fixed top-3 left-3 z-50">
            <Menu className="w-5 h-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[80%] sm:w-[300px] p-0 bg-card border-r-border">
          <div className="h-full flex flex-col">
            <div className="p-4 border-b border-border/50">
              <h2 className="text-lg font-bold bg-gradient-to-br from-white to-white/60 bg-clip-text text-transparent">AI Chat</h2>
            </div>
            <ScrollArea className="flex-1">
              <ConversationList />
            </ScrollArea>
          </div>
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-[280px] flex-col border-r border-border/50 bg-card/50 backdrop-blur-xl h-screen sticky top-0">
        <div className="p-4 border-b border-border/50 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <div className="w-3 h-3 bg-primary rounded-full animate-pulse" />
            </div>
            <span>AI Chat</span>
          </Link>
        </div>
        
        <ScrollArea className="flex-1">
          <ConversationList />
        </ScrollArea>

        <div className="p-4 border-t border-border/50 flex flex-col gap-2">
          <div className="flex items-center justify-center gap-4 mb-2">
            <a 
              href="https://youtube.com/your_youtube_channel" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-destructive/10 hover:bg-destructive/20 text-destructive transition-colors"
              title="YouTube"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
              </svg>
            </a>
            <a 
              href="https://t.me/your_telegram_link" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-primary/10 hover:bg-primary/20 text-primary transition-colors"
              title="Telegram"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.13-.31-1.08-.66.02-.18.27-.36.74-.55 2.91-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
              </svg>
            </a>
            <a 
              href="https://instagram.com/your_instagram_handle" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-pink-500/10 hover:bg-pink-500/20 text-pink-500 transition-colors"
              title="Instagram"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4.162 4.162 0 110-8.324A4.162 4.162 0 0112 16zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
              </svg>
            </a>
          </div>
          <div className="text-xs text-muted-foreground text-center">
            Designed with ❤️ by AI
          </div>
        </div>
      </div>
    </>
  );
}
