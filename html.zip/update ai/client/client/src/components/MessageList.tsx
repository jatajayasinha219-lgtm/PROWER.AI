import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import { motion, AnimatePresence } from "framer-motion";
import { User, Bot, Copy, Check } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { type Message } from "@/hooks/use-chat";

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  isStreaming: boolean;
  streamedContent: string;
}

export function MessageList({ messages, isLoading, isStreaming, streamedContent }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamedContent, isStreaming]);

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="flex gap-1">
          <span className="w-2 h-2 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
          <span className="w-2 h-2 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
          <span className="w-2 h-2 bg-primary/50 rounded-full animate-bounce"></span>
        </div>
      </div>
    );
  }

  if (messages.length === 0 && !isStreaming) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center p-8 opacity-0 animate-[fadeIn_0.5s_ease-out_forwards]">
        <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-purple-500/20 rounded-2xl flex items-center justify-center mb-6 shadow-xl shadow-primary/5">
          <Bot className="w-10 h-10 text-primary" />
        </div>
        <h3 className="text-2xl font-bold mb-2">How can I help you today?</h3>
        <p className="text-muted-foreground max-w-md">
          Ask me anything about code, creative writing, or general knowledge. I'm here to assist.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
      <AnimatePresence initial={false}>
        {messages.map((message) => (
          <MessageItem key={message.id} message={message} />
        ))}
        
        {isStreaming && (
          <MessageItem 
            key="streaming" 
            message={{
              id: -1,
              role: "assistant",
              content: streamedContent,
              createdAt: new Date(),
              conversationId: 0,
              attachments: []
            } as any}
            isStreaming={true}
          />
        )}
      </AnimatePresence>
      <div ref={bottomRef} className="h-1" />
    </div>
  );
}

function MessageItem({ message, isStreaming = false }: { message: Message, isStreaming?: boolean }) {
  const isUser = message.role === "user";
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex w-full gap-4 max-w-4xl mx-auto",
        isUser ? "flex-row-reverse" : "flex-row"
      )}
    >
      <div className={cn(
        "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 shadow-sm",
        isUser 
          ? "bg-primary text-primary-foreground" 
          : "bg-secondary text-secondary-foreground border border-border/50"
      )}>
        {isUser ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
      </div>

      <div className={cn(
        "flex flex-col gap-1 min-w-0 max-w-[85%] md:max-w-[75%]",
        isUser ? "items-end" : "items-start"
      )}>
        <div className="flex items-center gap-2 mb-1 opacity-50 text-xs px-1">
          <span className="font-medium capitalize">{message.role}</span>
          <span>•</span>
          <span>{format(new Date(message.createdAt), "h:mm a")}</span>
        </div>

        <div className={cn(
          "relative px-4 py-3 rounded-2xl shadow-sm text-sm leading-relaxed overflow-hidden group",
          isUser 
            ? "bg-primary text-primary-foreground rounded-tr-none" 
            : "bg-secondary/50 backdrop-blur-sm border border-border/50 text-foreground rounded-tl-none"
        )}>
          {/* Attachments */}
          {message.attachments && message.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {message.attachments.map((url, i) => (
                <img 
                  key={i} 
                  src={url} 
                  alt="Attachment" 
                  className="max-w-[200px] max-h-[200px] rounded-lg border border-border/50 cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() => window.open(url, '_blank')}
                />
              ))}
            </div>
          )}

          <div className={cn("prose prose-invert max-w-none prose-p:leading-relaxed prose-pre:bg-black/20 prose-code:text-primary-foreground/90", isUser && "prose-p:text-primary-foreground")}>
            <ReactMarkdown
              components={{
                code({node, inline, className, children, ...props}: any) {
                  const match = /language-(\w+)/.exec(className || '');
                  return !inline && match ? (
                    <div className="relative group/code">
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(String(children).replace(/\n$/, ''));
                        }}
                        className="absolute right-2 top-2 p-1 rounded-md bg-white/10 opacity-0 group-hover/code:opacity-100 hover:bg-white/20 transition-all z-10"
                      >
                        <Copy className="w-3 h-3 text-white" />
                      </button>
                      <code className={className} {...props}>
                        {children}
                      </code>
                    </div>
                  ) : (
                    <code className={className} {...props}>
                      {children}
                    </code>
                  )
                }
              }}
            >
              {message.content}
            </ReactMarkdown>
            {isStreaming && (
              <span className="inline-block w-1.5 h-4 ml-1 align-middle bg-current animate-pulse" />
            )}
          </div>

          {!isUser && !isStreaming && (
            <button
              onClick={copyToClipboard}
              className="absolute top-2 right-2 p-1.5 rounded-md bg-background/50 text-muted-foreground opacity-0 group-hover:opacity-100 hover:text-foreground transition-all duration-200"
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}
