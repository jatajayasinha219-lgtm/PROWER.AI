import { useState, useRef, useEffect } from "react";
import { SendHorizontal, Sparkles, Image as ImageIcon, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ObjectUploader } from "@/components/ObjectUploader";

interface ChatInputProps {
  onSend: (content: string, attachments?: string[]) => void;
  disabled: boolean;
}

export function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<string[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if ((!input.trim() && attachments.length === 0) || disabled) return;
    onSend(input, attachments);
    setInput("");
    setAttachments([]);
    
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="p-4 border-t border-border/50 bg-background/80 backdrop-blur-lg">
      <div className="max-w-4xl mx-auto relative group">
        {/* Attachment Previews */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-2 px-2">
            {attachments.map((url, i) => (
              <div key={i} className="relative group/thumb w-16 h-16 rounded-lg overflow-hidden border border-border">
                <img src={url} alt="Attachment" className="w-full h-full object-cover" />
                <button 
                  onClick={() => removeAttachment(i)}
                  className="absolute top-1 right-1 bg-black/50 rounded-full p-0.5 text-white opacity-0 group-hover/thumb:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/20 via-purple-500/20 to-primary/20 rounded-xl blur opacity-20 group-hover:opacity-40 transition duration-500"></div>
        
        <form 
          onSubmit={handleSubmit}
          className="relative flex items-end gap-2 bg-secondary/80 border border-border rounded-xl p-2 shadow-sm focus-within:ring-1 focus-within:ring-primary/50 transition-all duration-200"
        >
          <ObjectUploader
            onGetUploadParameters={async (file) => {
              const res = await fetch("/api/uploads/request-url", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  name: file.name,
                  size: file.size,
                  contentType: file.type,
                }),
              });
              const { uploadURL } = await res.json();
              return {
                method: "PUT",
                url: uploadURL,
                headers: { "Content-Type": file.type },
              };
            }}
            onComplete={(result) => {
              const urls = result.successful.map(f => f.uploadURL.split('?')[0]);
              setAttachments(prev => [...prev, ...urls]);
            }}
            buttonClassName="mb-0.5 shrink-0 rounded-lg h-9 w-9 p-0"
            maxNumberOfFiles={5}
          >
            <ImageIcon className="w-5 h-5" />
          </ObjectUploader>

          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Send a message..."
            disabled={disabled}
            className="min-h-[44px] max-h-[200px] w-full resize-none border-0 bg-transparent py-3 px-3 focus-visible:ring-0 placeholder:text-muted-foreground/50 shadow-none scrollbar-hide"
            rows={1}
          />
          
          <Button 
            type="submit" 
            size="icon" 
            disabled={(!input.trim() && attachments.length === 0) || disabled}
            className="mb-0.5 shrink-0 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95 disabled:hover:scale-100"
          >
            {disabled ? (
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
            ) : (
              <SendHorizontal className="w-5 h-5" />
            )}
          </Button>
        </form>
        
        <div className="absolute bottom-[-24px] right-0 text-[10px] text-muted-foreground/60 flex items-center gap-1">
          <Sparkles className="w-3 h-3" /> AI may produce inaccurate information
        </div>
      </div>
    </div>
  );
}
