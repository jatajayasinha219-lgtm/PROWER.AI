import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";
import { useState, useCallback } from "react";

// Types derived from schema
export type Conversation = z.infer<typeof api.conversations.list.responses[200]>[number];
export type Message = z.infer<typeof api.conversations.get.responses[200]>["messages"][number];
export type ConversationDetail = z.infer<typeof api.conversations.get.responses[200]>;

// Hook to fetch all conversations
export function useConversations() {
  return useQuery({
    queryKey: [api.conversations.list.path],
    queryFn: async () => {
      const res = await fetch(api.conversations.list.path);
      if (!res.ok) throw new Error("Failed to fetch conversations");
      return api.conversations.list.responses[200].parse(await res.json());
    },
  });
}

// Hook to fetch a single conversation with messages
export function useConversation(id: number | null) {
  return useQuery({
    queryKey: [api.conversations.get.path, id],
    queryFn: async () => {
      if (!id) return null;
      const url = buildUrl(api.conversations.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch conversation");
      return api.conversations.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

// Hook to create a new conversation
export function useCreateConversation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (title?: string) => {
      const res = await fetch(api.conversations.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title }),
      });
      if (!res.ok) throw new Error("Failed to create conversation");
      return api.conversations.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.conversations.list.path] });
    },
  });
}

// Hook to delete a conversation
export function useDeleteConversation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.conversations.delete.path, { id });
      const res = await fetch(url, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete conversation");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.conversations.list.path] });
    },
  });
}

// Custom hook for sending messages with streaming response
export function useSendMessage() {
  const queryClient = useQueryClient();
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedContent, setStreamedContent] = useState("");
  const [currentMessageId, setCurrentMessageId] = useState<string | null>(null);

  const sendMessage = useCallback(async (conversationId: number, content: string, attachments?: string[]) => {
    setIsStreaming(true);
    setStreamedContent("");
    const tempId = Math.random().toString(36).substring(7);
    setCurrentMessageId(tempId);

    try {
      const url = buildUrl(api.conversations.sendMessage.path, { id: conversationId });
      
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, attachments }),
      });

      if (!response.ok) throw new Error("Failed to send message");
      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const jsonStr = line.slice(6);
            if (!jsonStr) continue;
            
            try {
              const data = JSON.parse(jsonStr);
              if (data.done) {
                // Done streaming
              } else if (data.content) {
                setStreamedContent((prev) => prev + data.content);
              }
            } catch (e) {
              console.error("Failed to parse SSE data", e);
            }
          }
        }
      }
    } catch (error) {
      console.error("Stream error:", error);
      throw error;
    } finally {
      setIsStreaming(false);
      // Invalidate to fetch the final persisted message from DB
      queryClient.invalidateQueries({ queryKey: [api.conversations.get.path, conversationId] });
      setStreamedContent("");
      setCurrentMessageId(null);
    }
  }, [queryClient]);

  return { sendMessage, isStreaming, streamedContent, currentMessageId };
}
