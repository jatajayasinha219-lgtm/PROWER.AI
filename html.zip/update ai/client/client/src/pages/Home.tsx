import { useEffect } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Sparkles, ArrowRight, MessageSquare } from "lucide-react";
import { useCreateConversation } from "@/hooks/use-chat";
import { useLocation } from "wouter";

export default function Home() {
  const [, setLocation] = useLocation();
  const createMutation = useCreateConversation();

  const handleStart = async () => {
    const newConv = await createMutation.mutateAsync("New Chat");
    setLocation(`/chat/${newConv.id}`);
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[128px] -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[128px] translate-x-1/2 translate-y-1/2 pointer-events-none" />

        <div className="max-w-2xl w-full text-center space-y-8 relative z-10 animate-float">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-gradient-to-tr from-primary to-purple-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-primary/20 rotate-3 transition-transform hover:rotate-6 duration-300">
              <Sparkles className="w-10 h-10 text-white" />
            </div>
          </div>
          
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight bg-gradient-to-r from-white to-white/60 bg-clip-text text-transparent">
              Welcome to AI Chat
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-lg mx-auto">
              Your intelligent assistant for coding, creativity, and conversation. 
              Start a new chat to begin exploring.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button 
              size="lg" 
              onClick={handleStart} 
              disabled={createMutation.isPending}
              className="h-14 px-8 rounded-2xl text-lg gap-2 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all hover:-translate-y-0.5"
            >
              {createMutation.isPending ? (
                "Creating..." 
              ) : (
                <>
                  Start New Chat <ArrowRight className="w-5 h-5" />
                </>
              )}
            </Button>
            
            {/* Optional secondary button for future features */}
            {/* <Button variant="outline" size="lg" className="h-14 px-8 rounded-2xl text-lg gap-2">
              <MessageSquare className="w-5 h-5" /> History
            </Button> */}
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 max-w-4xl w-full">
          {[
            { title: "Smart Analysis", desc: "Advanced understanding of complex topics" },
            { title: "Creative Writing", desc: "Stories, poems, and content generation" },
            { title: "Code Assistant", desc: "Debugging, refactoring, and code generation" }
          ].map((feature, i) => (
            <div key={i} className="p-6 rounded-2xl bg-secondary/30 border border-border/50 backdrop-blur-sm hover:bg-secondary/50 transition-colors">
              <h3 className="font-semibold mb-2 text-foreground">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.desc}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
