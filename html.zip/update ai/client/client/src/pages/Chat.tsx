import { useEffect } from "react";
import { useRoute } from "wouter";
import { Sidebar } from "@/components/Sidebar";
import { MessageList } from "@/components/MessageList";
import { ChatInput } from "@/components/ChatInput";
import { useConversation, useSendMessage } from "@/hooks/use-chat";
import { useLocation } from "wouter";

export default function ChatPage() {
  const [match, params] = useRoute("/chat/:id");
  const [, setLocation] = useLocation();
  const conversationId = params?.id ? parseInt(params.id) : null;

  const { data: conversation, isLoading, error } = useConversation(conversationId);
  const { sendMessage, isStreaming, streamedContent } = useSendMessage();

  useEffect(() => {
    if (error) {
      setLocation("/");
    }
  }, [error, setLocation]);

  const handleSend = async (content: string, attachments?: string[]) => {
    if (conversationId) {
      await sendMessage(conversationId, content, attachments);
    }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-full relative">
        {/* Header */}
        <header className="h-14 border-b border-border/50 flex items-center justify-between px-6 bg-background/80 backdrop-blur-sm z-10 md:ml-0 ml-10">
          <div className="flex flex-col">
            <h1 className="font-semibold text-sm md:text-base truncate max-w-[200px] md:max-w-md">
              {conversation?.title || "New Conversation"}
            </h1>
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
              {conversationId ? `Chat #${conversationId}` : "Start Chatting"}
            </span>
          </div>
        </header>

        {/* Messages */}
        <MessageList 
          messages={conversation?.messages || []} 
          isLoading={isLoading && !conversation} 
          isStreaming={isStreaming}
          streamedContent={streamedContent}
        />

        {/* Input */}
        <ChatInput 
          onSend={handleSend} 
          disabled={isStreaming || isLoading} 
        />
      </main>
    </div>
  );
}
