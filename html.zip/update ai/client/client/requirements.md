## Packages
react-markdown | For rendering AI responses with formatting
date-fns | For friendly date formatting
framer-motion | For smooth message animations and transitions
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Plus Jakarta Sans", "sans-serif"],
}
